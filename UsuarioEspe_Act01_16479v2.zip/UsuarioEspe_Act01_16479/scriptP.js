document.getElementById('btnReset').addEventListener('click', function() {
    // Obtener los formularios
    const form1 = document.getElementById('form1');
    const form2 = document.getElementById('form2');
    
    // Reiniciar los formularios
    form1.reset();
    form2.reset();
});
